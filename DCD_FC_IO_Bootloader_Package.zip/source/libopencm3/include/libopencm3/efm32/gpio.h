/*
 * This file is part of the libopencm3 project.
 *
 * Copyright (C) 2015 Kuldeep Singh Dhaka <kuldeepdhaka9@gmail.com>
 *
 * This library is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this library. If not, see <http://www.gnu.org/licenses/>.
 */

#if defined(EFM32LG)
#	include <libopencm3/efm32/lg/gpio.h>
#elif defined(EFM32HG)
#	include <libopencm3/efm32/hg/gpio.h>
#elif defined(EFM32WG)
#	include <libopencm3/efm32/wg/gpio.h>
#elif defined(EZR32WG)
#	include <libopencm3/efm32/ezr32wg/gpio.h>
#else
#	error "efm32 family not defined."
#endif
