# Reproducing the DCD FC test build

Use an ArduPilot checkout at `663fc09bb25b84a756d8585e4f6d9266a0ab53ae` with its matching submodules and a configured build environment. The compiler used here is GNU Arm Embedded 10.2.1 (10-2020-q4-major).

Copy this directory's `libraries` tree into that checkout. Add `AP_HW_DCD_FC 1413` to `Tools/AP_Bootloader/board_types.txt` for this local test build only, ensuring the number is not assigned to another entry in that checkout. Keep the upstream license and source notices. An allocated production ID must be used consistently in the application and bootloader.

From the checkout root:

```sh
./waf configure --board iomcu-DCD-FC --no-submodule-update --Werror
./waf iofirmware
cp build/iomcu-DCD-FC/bin/iofirmware_lowpolh.bin Tools/IO_Firmware/iofirmware_DCD_FC_lowpolh.bin
./waf configure --board iomcu-DCD-FC-dshot --no-submodule-update --Werror
./waf iofirmware
cp build/iomcu-DCD-FC-dshot/bin/iofirmware_lowpolh.bin Tools/IO_Firmware/iofirmware_DCD_FC_dshot_lowpolh.bin
python3 Tools/scripts/build_bootloaders.py DCD-FC
./waf configure --board DCD-FC --no-submodule-update --Werror
./waf copter
```

The application is under `build/DCD-FC/bin`, and the bootloader is under `Tools/bootloaders`. The normal and DShot IO applications are embedded in the FMU firmware. Source-only settings have not been changed for this test build.
